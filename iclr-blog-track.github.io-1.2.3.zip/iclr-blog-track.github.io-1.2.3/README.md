# ICLR 2022 blog track

Call for blog posts: https://iclr-blog-track.github.io/

About: https://iclr-blog-track.github.io/about/ 

Submission guide: https://iclr-blog-track.github.io/submitting/

## Track Chairs / Proposal Authors

- Sebastien Bubeck, Microsoft
- David Dobre, MILA
- Charlie Gauthier, MILA
- Gauthier Gidel, MILA
- Claire Vernade, DeepMind

### Copyright notice for Lanyon/Poole:

#### **Mark Otto**
- <https://github.com/mdo>
- <https://twitter.com/mdo>

#### License

Open sourced under the [MIT license](LICENSE.md).
